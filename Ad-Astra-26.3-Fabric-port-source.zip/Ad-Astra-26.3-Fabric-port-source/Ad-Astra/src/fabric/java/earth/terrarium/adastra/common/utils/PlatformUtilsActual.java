package earth.terrarium.adastra.common.utils;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.component.CookingFuel;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.portal.DimensionTransition;
import net.msrandom.multiplatform.annotations.Actual;

import java.util.Optional;
import java.util.function.Supplier;

public class PlatformUtilsActual {

    @Actual
    public static Entity teleportToDimension(Entity entity, ServerLevel level, DimensionTransition transition) {
        return entity.changeDimension(transition);
    }

    @Actual
    public static Supplier<Item> createSpawnEggItem(Supplier<? extends EntityType<? extends Mob>> type, int primaryColor, int secondaryColor, Item.Properties properties) {
        return EggUtil.createEgg(type, primaryColor, secondaryColor, properties);
    }

    @Actual
    public static int getBurnTime(ItemStack burnable, ServerLevel level, BlockPos pos, BlockState state, BlockEntity blockEntity) {
        CookingFuel fuel = burnable.get(DataComponents.COOKING_FUEL);
        if (fuel == null) return 0;

        // 26.3 moved fuel values to data components. Providers are resolved
        // against the container-process loot context, not against the item alone.
        LootParams params = new LootParams.Builder(level)
            .withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(pos))
            .withParameter(LootContextParams.CONTAINER, blockEntity)
            .withParameter(LootContextParams.BLOCK_STATE, state)
            .withParameter(LootContextParams.BLOCK_ENTITY, blockEntity)
            .create(LootContextParamSets.CONTAINER_PROCESS);
        LootContext context = new LootContext.Builder(params)
            .withOptionalRandomSource(level.getRandom())
            .create(Optional.empty());
        return Math.max(0, fuel.burnTime().get(context, 0));
    }
}
