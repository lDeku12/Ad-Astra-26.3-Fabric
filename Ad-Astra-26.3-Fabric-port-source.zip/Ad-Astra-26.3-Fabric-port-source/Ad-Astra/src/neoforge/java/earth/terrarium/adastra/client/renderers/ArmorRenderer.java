package earth.terrarium.adastra.client.renderers;

import earth.terrarium.adastra.client.ClientPlatformUtils;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

public record ArmorRenderer(Identifier texture, ModelLayerLocation layer,
                            ClientPlatformUtils.ArmorFactory factory) {
}
