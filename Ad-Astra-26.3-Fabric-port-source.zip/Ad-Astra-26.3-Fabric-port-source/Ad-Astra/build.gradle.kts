import earth.terrarium.cloche.api.metadata.CommonMetadata
import groovy.json.StringEscapeUtils

plugins {
    java
    `maven-publish`
    id("com.teamresourceful.resourcefulgradle") version "0.0.+"
    id("earth.terrarium.cloche") version "0.18.15"
}

// Interceptar y redirigir cualquier versión conflictiva de Fabric API o librerías
configurations.all {
    resolutionStrategy.eachDependency {
        if (requested.group == "net.fabricmc.fabric-api" && requested.version == "0.164.0+26.3+26.3") {
            useVersion("0.102.0+1.21")
            because("Redirigir versión inexistente de Fabric API a una pública válida")
        }
    }
}

val minecraftVersion: String by project
val modId = project.name

base {
    archivesName.set("$modId-$minecraftVersion")
}

cloche {
    val reiVersion: String by project

    minecraftVersion = project.property("minecraftVersion") as String

    metadata {
        modId = "ad_astra"

        name = "Ad Astra"
        description = "Live long and prosper, Ad Astra!"

        url = "https://www.curseforge.com/minecraft/mc-mods/ad-astra"
        issues = "https://github.com/terrarium-earth/ad-astra/issues"
        icon = "icon.png"
        license = "Terrarium License"

        author("Alex Nijjar", "alex@terrarium.earth")
        contributor("CodexAdrian", "adrian@terrarium.earth")
        contributor("Facu")
        contributor("Fizz")
        contributor("MsRandom", "ashley@terrarium.earth")
        contributor("ThatGravyBoat", "sophie@terrarium.earth")
        contributor("Mrbysco")

        require("resourcefullib", "3.0.0")
        require("resourcefulconfig", "3.0.0")
        require("common_storage_lib", "0.0.11")
    }

    singleTarget {
        fabric {
            val fabricLoaderVersion: String by project

            includedClient()
            data()

            loaderVersion = fabricLoaderVersion

            mixins.from("src/main/adastra-common.mixins.json")
            mixins.from("src/fabric/adastra.mixins.json")

            metadata {
                entrypoint(
                    "main",
                    "earth.terrarium.adastra.fabric.AdAstraFabric::init"
                )
                entrypoint(
                    "main",
                    "earth.terrarium.adastra.AdAstra::postInit"
                )

                entrypoint(
                    "client",
                    "earth.terrarium.adastra.client.fabric.AdAstraClientFabric::init"
                )

                entrypoint(
                    "rei_client",
                    "earth.terrarium.adastra.common.compat.rei.AdAstraReiPlugin"
                )
                entrypoint(
                    "jei_mod_plugin",
                    "earth.terrarium.adastra.common.compat.jei.AdAstraJeiPlugin"
                )

                dependency {
                    modId = "fabric-api"
                    type = CommonMetadata.Dependency.Type.Required
                }
            }

            dependencies {
                val fabricApiVersion: String by project
                val modMenuVersion: String by project

                val resourcefulLibVersion: String by project
                val resourcefulConfigVersion: String by project
                val cslVersion: String by project
                val athenaVersion: String by project
                val jeiVersion: String by project

                fabricApi(fabricApiVersion)

                implementation(
                    module(
                        group = "javazoom",
                        name = "jlayer",
                        version = "1.0.1"
                    )
                )

                compileOnly(
                    module(
                        group = "me.shedaniel",
                        name = "REIPluginCompatibilities-forge-annotations",
                        version = "8.+"
                    )
                )
                compileOnly("org.jetbrains:annotations:26.1.0")
                compileOnly("com.teamresourceful:bytecodecs:1.1.2")

                modApi(
                    module(
                        group = "com.teamresourceful.resourcefullib",
                        name = "resourcefullib-$loaderName-${minecraftVersion.get()}",
                        version = resourcefulLibVersion
                    )
                )

                modApi(
                    module(
                        group = "com.teamresourceful.resourcefulconfig",
                        name = "resourcefulconfig-$loaderName-${minecraftVersion.get()}",
                        version = resourcefulConfigVersion
                    )
                )

                modApi(
                    module(
                        group = "earth.terrarium.common_storage_lib",
                        name = "common-storage-lib-$loaderName-${minecraftVersion.get()}",
                        version = cslVersion
                    )
                )

                modLocalRuntime(
                    module(
                        group = "me.shedaniel",
                        name = "RoughlyEnoughItems-fabric",
                        version = reiVersion
                    )
                )

                modLocalRuntime(
                    module(
                        group = "com.terraformersmc",
                        name = "modmenu",
                        version = modMenuVersion
                    )
                )

                modLocalRuntime(
                    module(
                        group = "maven.modrinth",
                        name = "jade",
                        version = "15.10.5+fabric"
                    )
                )

                modCompileOnly(
                    module(
                        group = "mezz.jei",
                        name = "jei-${minecraftVersion.get()}-$loaderName",
                        version = jeiVersion
                    )
                ) {
                    isTransitive = false
                }

                modLocalRuntime(
                    module(
                        group = "earth.terrarium.athena",
                        name = "athena-$loaderName-${minecraftVersion.get()}",
                        version = athenaVersion
                    )
                )

                modCompileOnly(
                    module(
                        group = "me.shedaniel",
                        name = "RoughlyEnoughItems-api-$loaderName",
                        version = reiVersion
                    )
                )

                modCompileOnly(
                    module(
                        group = "me.shedaniel",
                        name = "RoughlyEnoughItems-default-plugin-$loaderName",
                        version = reiVersion
                    )
                )

                val jlayer = module(
                    group = "javazoom",
                    name = "jlayer",
                    version = "1.0.1"
                )
                include(jlayer)
            }

            datagenDirectory = file("src/main/generated/resources")

            runs {
                client {}
                server {}
            }
        }
    }

    mappings {
        official()
    }
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(25))
    }
    withSourcesJar()
}

publishing {
    publications {
        create<MavenPublication>("maven") {
            from(components["java"])

            pom {
                val github = "https://github.com/terrarium-earth/Ad-Astra"

                name.set("Ad Astra")
                url.set(github)

                scm {
                    connection.set("git:$github.git")
                    developerConnection.set("git:$github.git")
                    url.set(github)
                }

                licenses {
                    license {
                        name.set(
                            "Terrarium Licence (https://gist.github.com/CodexAdrian/4bb2a1868bb2d2a91ca74ea40424e69d)"
                        )
                    }
                }
            }
        }
    }

    repositories {
        maven {
            setUrl("https://maven.teamresourceful.com/repository/terrarium/")
            credentials {
                username = System.getenv("MAVEN_USER")
                password = System.getenv("MAVEN_PASS")
            }
        }
    }
}

idea {
    module {
        excludeDirs.add(file("run"))
    }
}

resourcefulGradle {
    templates {
        register("embed") {
            val changelog: String =
                file("changelog.md").readText(Charsets.UTF_8)
            val fabricLink: String? = System.getenv("FABRIC_RELEASE_URL")
            val forgeLink: String? = System.getenv("FORGE_RELEASE_URL")

            source.set(file("templates/embed.json.template"))
            injectedValues.set(
                mapOf(
                    "minecraft" to minecraftVersion,
                    "version" to version,
                    "changelog" to StringEscapeUtils.escapeJava(changelog),
                    "fabric_link" to fabricLink.orEmpty(),
                    "forge_link" to forgeLink.orEmpty(),
                )
            )
        }
    }
}

tasks {
    withType(JavaCompile::class).configureEach {
        options.release.set(25)
        options.compilerArgs.addAll(listOf("-Xmaxerrs", "2000"))
    }
}