import earth.terrarium.cloche.api.metadata.CommonMetadata
import groovy.json.StringEscapeUtils

plugins {
    java
    `maven-publish`
    id("com.teamresourceful.resourcefulgradle") version "0.0.+"
    id("earth.terrarium.cloche") version "0.18.15"
}

// Interceptar y redirigir cualquier variante con sufijo -26.3 o versiones incompatibles
configurations.all {
    resolutionStrategy {
        eachDependency {
            if (requested.group == "net.fabricmc.fabric-api" || requested.name.contains("fabric-api")) {
                useVersion("0.102.0+1.21")
                because("Forzar versión pública válida de Fabric API")
            }
            if (requested.name.contains("resourcefullib")) {
                useVersion("3.0.0")
                because("Forzar versión estable de Resourceful Lib")
            }
            if (requested.name.contains("resourcefulconfig")) {
                useVersion("3.0.0")
                because("Forzar versión estable de Resourceful Config")
            }
            if (requested.name.contains("common-storage-lib")) {
                useVersion("0.0.11")
                because("Forzar versión estable de Common Storage Lib")
            }
            if (requested.name.contains("jei")) {
                useVersion("19.2.0.170")
                because("Forzar versión estable de JEI")
            }
        }
        dependencySubstitution {
            substitute(module("net.msrandom:stub"))
                .using(module("com.teamresourceful.resourcefullib:resourcefullib-fabric:3.0.0"))
                .because("Neutralizar stub fantasma")
        }
    }
}

val minecraftVersion = project.property("minecraftVersion") as String
val modId = project.name

base {
    archivesName.set("$modId-$minecraftVersion")
}

cloche {
    val reiVersion = project.property("reiVersion") as String

    minecraftVersion = project.property("minecraftVersion") as String

    metadata {
        modId = "ad_astra"

        name = "Ad Astra"
        description = "Live long and prosper, Ad Astra!"

        url = "https://www.curseforge.com/minecraft/mc-mods/ad-astra"
        issues = "https://github.com/terrarium-earth/ad-astra/issues"
        icon = "icon.png"
        license = "Terrarium License"

        author("Alex Nijjar", "alex@terrarium.earth")
        contributor("CodexAdrian", "adrian@terrarium.earth")
        contributor("Facu")
        contributor("Fizz")
        contributor("MsRandom", "ashley@terrarium.earth")
        contributor("ThatGravyBoat", "sophie@terrarium.earth")
        contributor("Mrbysco")

        require("resourcefullib", "3.0.0")
        require("resourcefulconfig", "3.0.0")
        require("common_storage_lib", "0.0.11")
    }

    singleTarget {
        fabric {
            val fabricLoaderVersion = project.property("fabricLoaderVersion") as String

            includedClient()
            data()

            loaderVersion = fabricLoaderVersion

            mixins.from("src/main/adastra-common.mixins.json")
            mixins.from("src/fabric/adastra.mixins.json")

            metadata {
                entrypoint(
                    "main",
                    "earth.terrarium.adastra.fabric.AdAstraFabric::init"
                )
                entrypoint(
                    "main",
                    "earth.terrarium.adastra.AdAstra::postInit"
                )

                entrypoint(
                    "client",
                    "earth.terrarium.adastra.client.fabric.AdAstraClientFabric::init"
                )

                entrypoint(
                    "rei_client",
                    "earth.terrarium.adastra.common.compat.rei.AdAstraReiPlugin"
                )
                entrypoint(
                    "jei_mod_plugin",
                    "earth.terrarium.adastra.common.compat.jei.AdAstraJeiPlugin"
                )

                dependency {
                    modId = "fabric-api"
                    type = CommonMetadata.Dependency.Type.Required
                }
            }

            dependencies {
                val fabricApiVersion = project.property("fabricApiVersion") as String
                val modMenuVersion = project.property("modMenuVersion") as String

                val resourcefulLibVersion = project.property("resourcefulLibVersion") as String
                val resourcefulConfigVersion = project.property("resourcefulConfigVersion") as String
                val cslVersion = project.property("cslVersion") as String
                val athenaVersion = project.property("athenaVersion") as String
                val jeiVersion = project.property("jeiVersion") as String

                fabricApi(fabricApiVersion) {
                    exclude(group = "net.fabricmc.fabric-api")
                }

                implementation("javazoom:jlayer:1.0.1")

                compileOnly("me.shedaniel:REIPluginCompatibilities-forge-annotations:8.+")
                compileOnly("org.jetbrains:annotations:26.1.0")
                compileOnly("com.teamresourceful:bytecodecs:1.1.2")

                modApi("com.teamresourceful.resourcefullib:resourcefullib-fabric:$resourcefulLibVersion")
                modApi("com.teamresourceful.resourcefulconfig:resourcefulconfig-fabric:$resourcefulConfigVersion")
                modApi("earth.terrarium.common_storage_lib:common-storage-lib-fabric:$cslVersion")

                modLocalRuntime("me.shedaniel:RoughlyEnoughItems-fabric:$reiVersion")
                modLocalRuntime("com.terraformersmc:modmenu:$modMenuVersion")
                modLocalRuntime("maven.modrinth:jade:15.10.5+fabric")

                modCompileOnly("mezz.jei:jei-fabric:$jeiVersion") {
                    isTransitive = false
                }

                modLocalRuntime("earth.terrarium.athena:athena-fabric:$athenaVersion")

                modCompileOnly("me.shedaniel:RoughlyEnoughItems-api-fabric:$reiVersion")
                modCompileOnly("me.shedaniel:RoughlyEnoughItems-default-plugin-fabric:$reiVersion")

                include("javazoom:jlayer:1.0.1")
            }

            datagenDirectory = file("src/main/generated/resources")

            runs {
                client {}
                server {}
            }
        }
    }

    mappings {
        official()
    }
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(25))
    }
    withSourcesJar()
}

publishing {
    publications {
        create<MavenPublication>("maven") {
            from(components["java"])

            pom {
                val github = "https://github.com/terrarium-earth/Ad-Astra"

                name.set("Ad Astra")
                url.set(github)

                scm {
                    connection.set("git:$github.git")
                    developerConnection.set("git:$github.git")
                    url.set(github)
                }

                licenses {
                    license {
                        name.set(
                            "Terrarium Licence (https://gist.github.com/CodexAdrian/4bb2a1868bb2d2a91ca74ea40424e69d)"
                        )
                    }
                }
            }
        }
    }

    repositories {
        maven {
            setUrl("https://maven.teamresourceful.com/repository/terrarium/")
            credentials {
                username = System.getenv("MAVEN_USER")
                password = System.getenv("MAVEN_PASS")
            }
        }
    }
}

idea {
    module {
        excludeDirs.add(file("run"))
    }
}

resourcefulGradle {
    templates {
        register("embed") {
            val changelog: String =
                file("changelog.md").readText(Charsets.UTF_8)
            val fabricLink: String? = System.getenv("FABRIC_RELEASE_URL")
            val forgeLink: String? = System.getenv("FORGE_RELEASE_URL")

            source.set(file("templates/embed.json.template"))
            injectedValues.set(
                mapOf(
                    "minecraft" to minecraftVersion,
                    "version" to version,
                    "changelog" to StringEscapeUtils.escapeJava(changelog),
                    "fabric_link" to fabricLink.orEmpty(),
                    "forge_link" to forgeLink.orEmpty(),
                )
            )
        }
    }
}

tasks {
    withType(JavaCompile::class).configureEach {
        options.release.set(25)
        options.compilerArgs.addAll(listOf("-Xmaxerrs", "2000"))
    }
}