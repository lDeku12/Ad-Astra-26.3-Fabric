# Ad Astra → Minecraft 26.3 Fabric — checkpoint 4

## Migraciones aplicadas
- Target Fabric-only para Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.164.0+26.3 y Java 25.
- Athena 4.7.3 y ResourcefulLib/ResourcefulConfig configurados para la línea 26.3.
- Common Storage Lib enlazada como composite build local en `settings.gradle.kts`.
- Referencias Java `ResourceLocation` migradas a `Identifier`.
- El combustible del generador se lee desde `DataComponents.COOKING_FUEL` y se resuelve mediante `LootContextParamSets.CONTAINER_PROCESS`.

## Estado
No compilado ni probado en el juego. Quedan migraciones de APIs de CSL, renderizado/HUD, worldgen, mixins y compatibilidad de REI/JEI. El entorno disponible solo tiene Java 21 y no puede descargar Gradle/dependencias; el target requiere Java 25.
