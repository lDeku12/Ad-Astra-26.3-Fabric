pluginManagement {
    repositories {
        gradlePluginPortal()
        maven(url = "https://maven.teamresourceful.com/repository/maven-public/")
        maven(url = "https://maven.msrandom.net/repository/cloche")
    }
}

enableFeaturePreview("TYPESAFE_PROJECT_ACCESSORS")

rootProject.name = "adastra"

includeBuild("../Common-Storage-Lib") {
    dependencySubstitution {
        substitute(module("earth.terrarium.common_storage_lib:common-storage-lib-fabric-26.3"))
            .using(project(":common-storage-lib-fabric"))
    }
}

includeBuild("../Athena") {
    dependencySubstitution {
        substitute(module("earth.terrarium.athena:athena-fabric-26.3"))
            .using(project(":fabric"))
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        mavenCentral()
        maven("https://maven.fabricmc.net/")
        maven("https://maven.msrandom.net/repository/cloche")
        maven("https://maven.teamresourceful.com/repository/maven-public/")
        maven("https://maven.shedaniel.me/")
        maven("https://maven.blamejared.com/")
        maven("https://libraries.minecraft.net/")
        maven("https://maven.neoforged.net/releases")
        maven("https://maven.neoforged.net/mojang-meta/")
        maven("https://maven.firstdarkdev.xyz/snapshots/")
        maven("https://api.modrinth.com/maven") {
            content {
                includeGroup("maven.modrinth")
            }
        }
        maven("https://www.cursemaven.com") {
            content {
                includeGroup("curse.maven")
            }
        }
    }
}