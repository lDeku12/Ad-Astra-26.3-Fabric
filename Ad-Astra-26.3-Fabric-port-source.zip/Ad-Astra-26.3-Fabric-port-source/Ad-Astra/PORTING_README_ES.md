# Ad Astra 26.3 Fabric — estado del port

Este ZIP contiene el primer checkpoint de migración del código fuente de Ad Astra 1.21.1 a una rama enfocada en Minecraft 26.3 + Fabric.

## Cambios realizados
- Minecraft: `26.3`
- Fabric Loader: `0.19.5`
- Fabric API: `0.163.0+26.3`
- Gradle Wrapper: `9.7.1`
- Toolchain Java configurado en 25
- Configuración de mappings Parchment 1.21 retirada
- Objetivo de compilación NeoForge retirado de esta rama para centrarse en Fabric
- ResourcefulLib y ResourcefulConfig actualizados a versiones que anuncian soporte 26.3

## Estado real
**No es todavía un mod jugable ni un JAR compilado.** No se debe instalar en Minecraft como si fuera una versión final. El código sigue teniendo APIs de 1.21.1 y dependencias que aún no están portadas/confirmadas para 26.3.

La compilación no pudo arrancar en el entorno de trabajo: el contenedor tiene Java 21 (26.3 necesita Java 25) y no puede resolver `services.gradle.org` por falta de acceso a red.

## Bloqueadores críticos
1. Common Storage Lib está publicado para 1.21–1.21.1 según su página pública; Ad Astra lo utiliza para energía/fluidos/inventarios.
2. Athena no anuncia una versión 26.3 compatible; las texturas conectadas/modelos necesitan una versión compatible o una alternativa.
3. `FuelRegistry` fue eliminado en 26.3 y el código Fabric aún lo importa.
4. Generación del mundo, reglas de superficie/material, datos y registros necesitan migración.
5. El sistema de renderizado cambió de forma importante en 26.3 (Blaze3D → Renderpearl, HUD, shaders y mixins).
6. Compatibilidad de REI/JEI y sus plugins aún no está resuelta.

## Cómo validar cuando haya JDK 25 y red
Desde esta carpeta:

```bash
./gradlew build
```

No considerar terminado el port hasta que compile, arranque cliente y servidor dedicados, y se prueben: generación de planetas, cohetes, viaje dimensional, gravedad, oxígeno, máquinas, fluidos/energía, recetas, GUIs y renderizado.
