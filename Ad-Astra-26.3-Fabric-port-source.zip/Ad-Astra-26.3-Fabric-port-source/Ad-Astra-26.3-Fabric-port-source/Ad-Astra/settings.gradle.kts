enableFeaturePreview("TYPESAFE_PROJECT_ACCESSORS")

rootProject.name = "adastra"

// Build the 26.3 port of Common Storage Lib from the sibling source checkout
// instead of accidentally resolving the old 1.21.x binary from Maven.
includeBuild("../Common-Storage-Lib") {
    dependencySubstitution {
        substitute(module("earth.terrarium.common_storage_lib:common-storage-lib-fabric-26.3"))
            .using(project(":common-storage-lib-fabric"))
    }
}

// Build the supplied 26.3-compatible Athena sources instead of relying on a
// remotely published artifact that may not exist in this exact MC version.
includeBuild("../Athena") {
    dependencySubstitution {
        substitute(module("earth.terrarium.athena:athena-fabric-26.3"))
            .using(project(":fabric"))
    }
}

pluginManagement {
    repositories {
        gradlePluginPortal()
        maven(url = "https://maven.teamresourceful.com/repository/maven-public/")
        maven(url = "https://maven.msrandom.net/repository/cloche")
    }
}
