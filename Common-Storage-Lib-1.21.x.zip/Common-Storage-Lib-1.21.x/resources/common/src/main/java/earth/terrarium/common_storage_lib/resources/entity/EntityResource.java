package earth.terrarium.common_storage_lib.resources.entity;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import earth.terrarium.common_storage_lib.resources.ResourceComponent;
import earth.terrarium.common_storage_lib.resources.ResourceStack;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.PatchedDataComponentMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.entity.EntityType;
import org.jetbrains.annotations.Nullable;

public final class EntityResource extends ResourceComponent {
    public static EntityResource BLANK = EntityResource.of((EntityType<?>) null);

    public static final Codec<EntityResource> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            BuiltInRegistries.ENTITY_TYPE.byNameCodec().fieldOf("type").forGetter(EntityResource::getType),
            DataComponentPatch.CODEC.optionalFieldOf("components", DataComponentPatch.EMPTY).forGetter(EntityResource::getDataPatch)
    ).apply(instance, EntityResource::of));

    public static final Codec<EntityResource> SIMPLE_CODEC = BuiltInRegistries.ENTITY_TYPE.byNameCodec().xmap(EntityResource::of, EntityResource::getType);

    public static final MapCodec<EntityResource> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            BuiltInRegistries.ENTITY_TYPE.byNameCodec().fieldOf("type").forGetter(EntityResource::getType),
            DataComponentPatch.CODEC.optionalFieldOf("components", DataComponentPatch.EMPTY).forGetter(EntityResource::getDataPatch)
    ).apply(instance, EntityResource::of));

    public static final StreamCodec<RegistryFriendlyByteBuf, EntityResource> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.holderRegistry(Registries.ENTITY_TYPE),
            EntityResource::toHolder,
            DataComponentPatch.STREAM_CODEC,
            EntityResource::getDataPatch,
            EntityResource::of);

    public static EntityResource of(EntityType<?> type) {
        return of(type, DataComponentPatch.EMPTY);
    }

    public static EntityResource of(Holder<EntityType<?>> type) {
        return of(type.value(), DataComponentPatch.EMPTY);
    }

    public static EntityResource of(EntityType<?> type, DataComponentPatch patch) {
        return new EntityResource(type, patch);
    }

    public static EntityResource of(Holder<EntityType<?>> type, DataComponentPatch patch) {
        return of(type.value(), patch);
    }

    private final EntityType<?> type;

    private EntityResource(@Nullable EntityType<?> type, DataComponentPatch components) {
        super(components);
        this.type = type;
    }

    public boolean isOf(EntityType<?> type) {
        return this.type == type;
    }

    @Override
    public boolean isBlank() {
        return type == null;
    }

    @Nullable
    public EntityType<?> getType() {
        return type;
    }

    public <D> EntityResource set(DataComponentType<D> type, D value) {
        return new EntityResource(this.type, addChanges(dataPatch, type, value));
    }

    public EntityResource modify(DataComponentPatch patch) {
        return new EntityResource(type, mergeChanges(this.dataPatch, patch));
    }

    public ResourceStack<EntityResource> toStack(long amount) {
        return new ResourceStack<>(this, amount);
    }

    public Holder<EntityType<?>> toHolder() {
        return type.builtInRegistryHolder();
    }
}
