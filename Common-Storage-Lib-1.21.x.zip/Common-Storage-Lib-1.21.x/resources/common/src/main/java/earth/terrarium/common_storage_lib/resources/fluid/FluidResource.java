package earth.terrarium.common_storage_lib.resources.fluid;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import earth.terrarium.common_storage_lib.resources.ResourceComponent;
import earth.terrarium.common_storage_lib.resources.ResourceStack;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.PatchedDataComponentMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;

public final class FluidResource extends ResourceComponent {
    public static final FluidResource BLANK = FluidResource.of(Fluids.EMPTY, DataComponentPatch.EMPTY);

    public static final MapCodec<FluidResource> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            BuiltInRegistries.FLUID.byNameCodec().fieldOf("id").forGetter(FluidResource::getType),
            DataComponentPatch.CODEC.optionalFieldOf("components", DataComponentPatch.EMPTY).forGetter(FluidResource::getDataPatch)
    ).apply(instance, FluidResource::of));

    public static final Codec<FluidResource> CODEC = MAP_CODEC.codec();

    public static final Codec<FluidResource> SIMPLE_CODEC = BuiltInRegistries.FLUID.byNameCodec().xmap(FluidResource::of, FluidResource::getType);

    public static final StreamCodec<? super RegistryFriendlyByteBuf, FluidResource> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.holderRegistry(Registries.FLUID),
            FluidResource::asHolder,
            DataComponentPatch.STREAM_CODEC,
            FluidResource::getDataPatch,
            FluidResource::of
    );

    public static FluidResource of(Fluid fluid) {
        return new FluidResource(fluid, DataComponentPatch.EMPTY);
    }

    public static FluidResource of(Holder<Fluid> holder) {
        return of(holder.value());
    }

    public static FluidResource of(Fluid fluid, DataComponentPatch components) {
        return new FluidResource(fluid, components);
    }

    public static FluidResource of(Holder<Fluid> holder, DataComponentPatch components) {
        return of(holder.value(), components);
    }

    private final Fluid type;

    /**
     * Immutable fluid resource representing a fluid stack
     * @param type type o' fluid
     * @param components data o' fluid
     * @deprecated Use the static of methods
     */
    @Deprecated
    public FluidResource(Fluid type, DataComponentPatch components) {
        super(components);
        this.type = type;
    }

    public Fluid getType() {
        return type;
    }

    public boolean isOf(Fluid type) {
        return getType() == type;
    }

    @Override
    public boolean isBlank() {
        return getType() == Fluids.EMPTY;
    }

    public <D> FluidResource set(DataComponentType<D> type, D value) {
        return new FluidResource(this.type, addChanges(this.dataPatch, type, value));
    }

    public FluidResource modify(DataComponentPatch patch) {
        return new FluidResource(this.type, mergeChanges(this.dataPatch, patch));
    }

    public ResourceStack<FluidResource> toStack(long amount) {
        return new ResourceStack<>(this, amount);
    }

    public Holder<Fluid> asHolder() {
        return type.builtInRegistryHolder();
    }

    public boolean is(TagKey<Fluid> tag) {
        return type.is(tag);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof FluidResource other)) return false;
        if (this.type != other.type) return false;
        return this.dataPatch.equals(other.dataPatch);
    }

    @Override
    public int hashCode() {
        int result = type.hashCode();
        result = 31 * result + dataPatch.hashCode();
        return result;
    }
}
