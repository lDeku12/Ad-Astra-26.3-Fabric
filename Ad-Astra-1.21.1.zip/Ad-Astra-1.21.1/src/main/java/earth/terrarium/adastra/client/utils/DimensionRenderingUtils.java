package earth.terrarium.adastra.client.utils;

import earth.terrarium.adastra.AdAstra;
import earth.terrarium.adastra.mixins.client.LevelRendererAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

public class DimensionRenderingUtils {

    public static final ResourceLocation BACKLIGHT = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/backlight.png");

    public static final ResourceLocation SUN = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/sun.png");
    public static final ResourceLocation BLUE_SUN = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/blue_sun.png");
    public static final ResourceLocation RED_SUN = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/red_sun.png");

    public static final ResourceLocation EARTH = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/earth.png");
    public static final ResourceLocation MOON = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/moon.png");
    public static final ResourceLocation MARS = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/mars.png");
    public static final ResourceLocation VENUS = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/venus.png");
    public static final ResourceLocation MERCURY = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/mercury.png");
    public static final ResourceLocation GLACIO = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/glacio.png");

    public static final ResourceLocation PHOBOS = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/phobos.png");
    public static final ResourceLocation DEIMOS = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/deimos.png");
    public static final ResourceLocation VICINUS = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/vicinus.png");

    public static final ResourceLocation ACID_RAIN = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/acid_rain.png");
    public static final ResourceLocation VENUS_CLOUDS = ResourceLocation.fromNamespaceAndPath(AdAstra.MOD_ID, "textures/environment/venus_clouds.png");

    public static final List<ResourceLocation> SOLAR_SYSTEM_TEXTURES = List.of(
        DimensionRenderingUtils.MERCURY,
        DimensionRenderingUtils.VENUS,
        DimensionRenderingUtils.EARTH,
        DimensionRenderingUtils.MARS
    );

    public static int getTicks() {
        return ((LevelRendererAccessor) Minecraft.getInstance().levelRenderer).getTicks();
    }
}
